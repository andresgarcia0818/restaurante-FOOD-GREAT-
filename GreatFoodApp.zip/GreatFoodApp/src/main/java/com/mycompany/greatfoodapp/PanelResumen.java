/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.greatfoodapp;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author TORRE
 */


public class PanelResumen extends JPanel {

    private GreatFoodFrame frame;
    private Sistema sistema;

    public PanelResumen(GreatFoodFrame frame, Sistema sistema) {
        this.frame = frame;
        this.sistema = sistema;
        setLayout(new BorderLayout());
    }

    public void mostrarResumen(Pedido pedido) {
        StringBuilder sb = new StringBuilder();
        sb.append("Cliente: ").append(pedido.getCliente().getNombre()).append("\n\n");
        double total = 0;
        for(Plato p : pedido.getPlatos()) {
            sb.append(p.toString()).append("\n");
            total += p.getPrecio();
        }
        sb.append("\nTotal a pagar: $").append(total);

        JOptionPane.showMessageDialog(this, sb.toString(), "Resumen del Pedido", JOptionPane.INFORMATION_MESSAGE);
    }
}
