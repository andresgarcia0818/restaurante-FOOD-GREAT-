/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.greatfoodapp;

/**
 *
 * @author TORRE
 */

public class Resultado {

    private boolean exito;
    private String mensaje;
    private double total;

    public Resultado() {}

    public Resultado(boolean exito, String mensaje, double total) {
        this.exito = exito;
        this.mensaje = mensaje;
        this.total = total;
    }

    public boolean isExito() { return exito; }
    public void setExito(boolean exito) { this.exito = exito; }

    public String getMensaje() { return mensaje; }
    public void setMensaje(String mensaje) { this.mensaje = mensaje; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }

    public void mostrarResultado() {
        System.out.println("Resultado: " + (exito ? "Éxito" : "Error"));
        System.out.println("Mensaje: " + mensaje);
        System.out.println("Total a pagar: $" + total);
    }
}
