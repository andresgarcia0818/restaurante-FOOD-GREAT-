/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.greatfoodapp;

/**
 *
 * @author TORRE
 */
public class ClienteHabitual extends Cliente {
    private String telefono;
    private String correo;

    public ClienteHabitual(int id, String nombre, String tel, String correo) {
        super(id, nombre);
        this.telefono = tel;
        this.correo = correo;
    }

    @Override
    public void mostrarInfo() {
        System.out.println("Cliente: " + nombre);
        System.out.println("Teléfono: " + telefono);
        System.out.println("Correo: " + correo);
    }
}
