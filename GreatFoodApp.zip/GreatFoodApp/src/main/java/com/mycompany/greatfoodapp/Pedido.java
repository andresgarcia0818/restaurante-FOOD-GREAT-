/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.greatfoodapp;
import java.util.ArrayList;
/**
 *
 * @author TORRE
 */

public class Pedido {
    private int id;
    private Cliente cliente;
    private ArrayList<Plato> platos = new ArrayList<>();

    public Pedido(int id, Cliente cliente) {
        this.id = id;
        this.cliente = cliente;
    }

    public void agregarPlato(Plato p) {
        platos.add(p);
    }

    public ArrayList<Plato> getPlatos() {
        return platos;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void mostrarResumen() {
        System.out.println("\n--- RESUMEN DEL PEDIDO ---");
        cliente.mostrarInfo();

        double total = 0;
        for (Plato p : platos) {
            System.out.println(p);
            total += p.getPrecio();
        }

        System.out.println("Total a pagar: $" + total);
        System.out.println("Recuerda acercarte a caja para pagar.");
    }
}
