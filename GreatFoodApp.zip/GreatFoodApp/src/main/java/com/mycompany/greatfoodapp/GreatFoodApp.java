/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.greatfoodapp;
import javax.swing.SwingUtilities;
/**
 *
 * @author TORRE
 */


public class GreatFoodApp {





    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GreatFoodFrame frame = new GreatFoodFrame();
            frame.setVisible(true);
        });
    }
}
