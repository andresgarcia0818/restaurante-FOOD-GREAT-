/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.greatfoodapp;
import java.awt.CardLayout;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
/**
 *
 * @author TORRE
 */


public class GreatFoodFrame extends JFrame {

    private CardLayout layout;

    // Paneles
    private PanelInicio panelInicio;
    private PanelClienteOpciones panelClienteOpciones;
    private PanelEmpleado panelEmpleado;
    private PanelMenu panelMenu;
    private PanelResumen panelResumen;

    // Sistema de negocio
    private Sistema sistema;

    public GreatFoodFrame() {
        sistema = new Sistema();

        setTitle("Great Food - Sistema Restaurante");
        setSize(600, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        layout = new CardLayout();
        setLayout(layout);

        // Crear paneles
        panelInicio = new PanelInicio(this);
        panelClienteOpciones = new PanelClienteOpciones(this, sistema);
        panelEmpleado = new PanelEmpleado(this, sistema);
        panelMenu = new PanelMenu(this, sistema);
        panelResumen = new PanelResumen(this, sistema);

        // Añadir paneles
        add(panelInicio, "inicio");
        add(panelClienteOpciones, "clienteOpciones");
        add(panelEmpleado, "empleado");
        add(panelMenu, "menu");
        add(panelResumen, "resumen");

        showScreen("inicio");
    }

    public void showScreen(String name) {
        layout.show(getContentPane(), name);
    }

    // Getters
    public Sistema getSistema() {
        return sistema;
    }

    public PanelMenu getPanelMenu() {
        return panelMenu;
    }

    public PanelResumen getPanelResumen() {
        return panelResumen;
    }
}
