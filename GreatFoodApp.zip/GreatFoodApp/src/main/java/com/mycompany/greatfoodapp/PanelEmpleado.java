/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.greatfoodapp;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author TORRE
 */

public class PanelEmpleado extends JPanel {

    private GreatFoodFrame frame;
    private Sistema sistema;

    public PanelEmpleado(GreatFoodFrame frame, Sistema sistema) {
        this.frame = frame;
        this.sistema = sistema;

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel lblTitulo = new JLabel("Panel Empleado");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(lblTitulo, gbc);

        // Botón Agregar Plato
        JButton btnAgregar = new JButton("Agregar Plato");
        gbc.gridy = 1; gbc.gridwidth = 2;
        add(btnAgregar, gbc);
        btnAgregar.addActionListener(e -> {
            String nombre = JOptionPane.showInputDialog(this, "Nombre del plato:");
            String precioStr = JOptionPane.showInputDialog(this, "Precio del plato:");

            if (nombre != null && precioStr != null && !nombre.isEmpty() && !precioStr.isEmpty()) {
                try {
                    double precio = Double.parseDouble(precioStr);
                    sistema.getPlatos().add(new Plato(nombre, precio));
                    JOptionPane.showMessageDialog(this, "Plato agregado correctamente.");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Precio inválido.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Debe completar todos los campos.");
            }
        });

        // Botón Ver Estadísticas
        JButton btnEstadisticas = new JButton("Ver Estadísticas");
        gbc.gridy = 2;
        add(btnEstadisticas, gbc);
        btnEstadisticas.addActionListener(e -> {
            sistema.mostrarEstadisticas();
        });

        // Botón Volver
        JButton btnVolver = new JButton("Volver");
        gbc.gridy = 3;
        add(btnVolver, gbc);
        btnVolver.addActionListener(e -> frame.showScreen("inicio"));
    }
}
