/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.greatfoodapp;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author TORRE
 */

public class PanelMenu extends JPanel {

    private GreatFoodFrame frame;
    private Sistema sistema;
    private JPanel platosPanel;
    private Pedido pedidoActual;

    public PanelMenu(GreatFoodFrame frame, Sistema sistema) {
        this.frame = frame;
        this.sistema = sistema;
        setLayout(new BorderLayout());

        JLabel lblTitulo = new JLabel("Menú de Platos");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        add(lblTitulo, BorderLayout.NORTH);

        platosPanel = new JPanel(new GridLayout(0, 1, 5, 5));
        add(new JScrollPane(platosPanel), BorderLayout.CENTER);

        JButton btnFinalizar = new JButton("Finalizar Pedido");
        btnFinalizar.addActionListener(e -> finalizarPedido());
        add(btnFinalizar, BorderLayout.SOUTH);
        

       
        
    }
    
   
    public void mostrarMenu(Cliente cliente) {
        pedidoActual = new Pedido(sistema.getPedidos().size() + 1, cliente);
        platosPanel.removeAll();

        for(Plato pl : sistema.getPlatos()) {
            JButton btnPlato = new JButton(pl.toString());
            btnPlato.addActionListener(e -> {
                pedidoActual.agregarPlato(pl);
                JOptionPane.showMessageDialog(this, pl.getNombre() + " agregado al pedido.");
            });
            platosPanel.add(btnPlato);
        }

        revalidate();
        repaint();
    }

    private void finalizarPedido() {
        if(pedidoActual != null) {
            sistema.getPedidos().add(pedidoActual);
            frame.getPanelResumen().mostrarResumen(pedidoActual);
            frame.showScreen("inicio");
        }
    }
}
