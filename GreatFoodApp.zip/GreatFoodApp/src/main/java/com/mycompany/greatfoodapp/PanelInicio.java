/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.greatfoodapp;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author TORRE
 */


public class PanelInicio extends JPanel {

    private GreatFoodFrame frame;

    public PanelInicio(GreatFoodFrame frame) {
        this.frame = frame;

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Título
        JLabel lblTitulo = new JLabel("GREAT FOOD");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(lblTitulo, gbc);

        // Botón Cliente
        JButton btnCliente = new JButton("Cliente");
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        add(btnCliente, gbc);
        btnCliente.addActionListener(e -> frame.showScreen("clienteOpciones"));

        // Botón Empleado
        JButton btnEmpleado = new JButton("Empleado");
        gbc.gridx = 1; gbc.gridy = 1;
        add(btnEmpleado, gbc);
        btnEmpleado.addActionListener(e -> {
            String contrasena = JOptionPane.showInputDialog(this, "Ingrese la contraseña del empleado:");
            if (contrasena != null && contrasena.equals("1234")) { // Cambia "1234" por tu contraseña real
                frame.showScreen("empleado");
            } else {
                JOptionPane.showMessageDialog(this, "Contraseña incorrecta.");
            }
        });

        // Botón Salir
        JButton btnSalir = new JButton("Salir");
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        add(btnSalir, gbc);
        btnSalir.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                    "¿Está seguro que desea salir?", "Confirmar salida",
                    JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        });
    }
}

