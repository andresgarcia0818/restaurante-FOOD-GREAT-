/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.greatfoodapp;

/**
 *
 * @author TORRE
 */

public class ClienteOcasional extends Cliente {
    public ClienteOcasional(int id) {
        super(id, "Cliente Ocasional");
    }

    @Override
    public void mostrarInfo() {
        System.out.println("Cliente Ocasional");
    }
}
