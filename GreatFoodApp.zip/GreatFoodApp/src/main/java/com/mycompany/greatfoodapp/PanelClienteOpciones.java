/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.greatfoodapp;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author TORRE
 */


public class PanelClienteOpciones extends JPanel {

    private GreatFoodFrame frame;
    private Sistema sistema;

    public PanelClienteOpciones(GreatFoodFrame frame, Sistema sistema) {
        this.frame = frame;
        this.sistema = sistema;
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);

        JLabel lblTitulo = new JLabel("Opciones Cliente");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(lblTitulo, gbc);

        JButton btnCrearPedido = new JButton("Crear Pedido");
        JButton btnVolver = new JButton("Volver");

        gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.gridy = 1;
        add(btnCrearPedido, gbc);
        gbc.gridx = 1;
        add(btnVolver, gbc);

        btnCrearPedido.addActionListener(e -> crearPedido());
        btnVolver.addActionListener(e -> frame.showScreen("inicio"));
    }
    

    private void crearPedido() {
        Cliente cliente;
        if(!sistema.getClientes().isEmpty()) {
            String[] opciones = {"Cliente registrado", "Cliente ocasional"};
            int opcion = JOptionPane.showOptionDialog(this, "¿Cliente registrado?", "Cliente",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
            if(opcion == 0) cliente = sistema.getClientes().get(0);
            else cliente = new ClienteOcasional(sistema.getClientes().size() + 1);
        } else {
            cliente = new ClienteOcasional(sistema.getClientes().size() + 1);
        }

        frame.getPanelMenu().mostrarMenu(cliente);
        frame.showScreen("menu");
    }
}
