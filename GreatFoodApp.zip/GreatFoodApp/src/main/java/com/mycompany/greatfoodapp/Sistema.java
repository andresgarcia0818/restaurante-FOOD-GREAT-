/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.greatfoodapp;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author TORRE
 */


public class Sistema {

    private ArrayList<Cliente> clientes = new ArrayList<>();
    private ArrayList<Plato> platos = new ArrayList<>();
    private ArrayList<Pedido> pedidos = new ArrayList<>();

    private int idCliente = 1;
    private int idPedido = 1;

    // Getters para GUI
    public ArrayList<Plato> getPlatos() {
        return platos;
    }

    public ArrayList<Pedido> getPedidos() {
        return pedidos;
    }

    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    // ================= REGISTRAR PLATO =================
    public void menuRegistrarPlato(Scanner sc) {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n--- REGISTRAR PLATO ---");
            System.out.println("1. Crear plato");
            System.out.println("2. Volver");
            System.out.print("Opción: ");

            int op = sc.nextInt();
            sc.nextLine();

            switch (op) {
                case 1 -> {
                    System.out.print("Nombre del plato: ");
                    String nombre = sc.nextLine();
                    System.out.print("Precio: ");
                    double precio = sc.nextDouble();
                    sc.nextLine();
                    platos.add(new Plato(nombre, precio));
                    System.out.println("Plato registrado correctamente.");
                }
                case 2 -> volver = true;
                default -> System.out.println("Opción inválida.");
            }
        }
    }

    // ================= REGISTRAR CLIENTE =================
    public void menuRegistrarCliente(Scanner sc) {
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Teléfono: ");
        String tel = sc.nextLine();
        System.out.print("Correo: ");
        String correo = sc.nextLine();
        clientes.add(new ClienteHabitual(idCliente++, nombre, tel, correo));
        System.out.println("Cliente registrado correctamente.");
    }

    // ================= CREAR PEDIDO =================
    public void menuCrearPedido(Scanner sc) {
        if (platos.isEmpty()) {
            System.out.println("No hay platos registrados.");
            return;
        }

        Cliente cliente;
        System.out.println("\n¿Cliente registrado?");
        System.out.println("1. Sí");
        System.out.println("2. No (cliente ocasional)");
        System.out.print("Opción: ");
        int op = sc.nextInt();
        sc.nextLine();

        if (op == 1 && !clientes.isEmpty()) {
            cliente = clientes.get(0); // simplificado
        } else {
            cliente = new ClienteOcasional(idCliente++);
        }

        Pedido pedido = new Pedido(idPedido++, cliente);

        boolean continuar = true;
        while (continuar) {
            System.out.println("\n--- PLATOS DISPONIBLES ---");
            for (int i = 0; i < platos.size(); i++) {
                System.out.println((i + 1) + ". " + platos.get(i));
            }
            System.out.println("0. Finalizar pedido");
            System.out.print("Seleccione una opción: ");
            int opcion = sc.nextInt();
            sc.nextLine();

            if (opcion == 0) {
                continuar = false;
            } else if (opcion >= 1 && opcion <= platos.size()) {
                pedido.agregarPlato(platos.get(opcion - 1));
                System.out.println("Plato agregado al pedido.");
            } else {
                System.out.println("Opción inválida.");
            }
        }

        pedidos.add(pedido);
        pedido.mostrarResumen();
        System.out.println("\nPresione ENTER para volver al menú principal...");
        sc.nextLine();
    }

    // ================= ESTADÍSTICAS =================
    public void mostrarEstadisticas() {
        if (pedidos.isEmpty()) {
            System.out.println("No hay pedidos registrados.");
            return;
        }

        double totalGanancias = 0;
        ArrayList<String> nombres = new ArrayList<>();
        ArrayList<Integer> cantidades = new ArrayList<>();

        for (Pedido pedido : pedidos) {
            for (Plato pl : pedido.getPlatos()) {
                totalGanancias += pl.getPrecio();
                if (nombres.contains(pl.getNombre())) {
                    int i = nombres.indexOf(pl.getNombre());
                    cantidades.set(i, cantidades.get(i) + 1);
                } else {
                    nombres.add(pl.getNombre());
                    cantidades.add(1);
                }
            }
        }

        System.out.println("\n=== ESTADÍSTICAS DE GREAT FOOD ===");
        System.out.println("Total de ganancias: $" + totalGanancias);
        for (int i = 0; i < nombres.size(); i++) {
            System.out.println("- " + nombres.get(i) + ": " + cantidades.get(i));
        }
    }
}
